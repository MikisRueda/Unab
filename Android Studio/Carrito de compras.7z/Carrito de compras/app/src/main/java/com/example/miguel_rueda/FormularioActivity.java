package com.example.miguel_rueda;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.*;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.firestore.FirebaseFirestore;

public class FormularioActivity extends AppCompatActivity {
    public EditText etnombre, etprecio, etimagen;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.agregar_producto);

        etnombre = findViewById(R.id.et_nombre);
        etprecio = findViewById(R.id.et_precio);
        etimagen = findViewById(R.id.et_url);
    }

    public void clickGuardar(View view)
    {
        String nombre = etnombre.getText().toString();
        Double precio = Double.parseDouble(etprecio.getText().toString());
        String url = etimagen.getText().toString();

        Producto nuevoProducto = new Producto();
        nuevoProducto.setNombre(nombre);
        nuevoProducto.setPrecio(precio);
        nuevoProducto.setUrlImagen(url);

        FirebaseFirestore firestore = FirebaseFirestore.getInstance();
        firestore.collection("productos").add(nuevoProducto);

        Toast.makeText(this, "Producto creado", Toast.LENGTH_SHORT).show();
        finish();
    }
}
