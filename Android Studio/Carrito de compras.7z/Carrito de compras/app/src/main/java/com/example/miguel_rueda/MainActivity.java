package com.example.miguel_rueda;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.*;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Producto> listaPrincipalProductos;
    private RecyclerView rvListadoProductos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cargarDatos();

        rvListadoProductos = findViewById(R.id.rv_listado_productos);

        Adaptador miAdaptador = new Adaptador(listaPrincipalProductos);

        rvListadoProductos.setAdapter(miAdaptador);
        rvListadoProductos.setLayoutManager(new LinearLayoutManager(this));

        miAdaptador.setOnItemClickListener(new Adaptador.OnItemClickListener() {
            @Override
            public void onItemClick(Producto miProducto, int posicion) {
                Toast.makeText(MainActivity.this, "CLICK DESDE ACTIVITY" + miProducto.getNombre(), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onItemButtonEliminar(Producto miProducto, int posicion) {
                listaPrincipalProductos.remove(posicion);
                miAdaptador.setListadoInformacion(listaPrincipalProductos);
            }
        });
    }

    public void cargarDatos(){

        //Crear productos

        Producto producto1 = new Producto();
        producto1.setNombre("Computador");
        producto1.setPrecio(2150000.0);
        producto1.setUrlImagen("https://th.bing.com/th/id/R.8144fc12c44cb71dada1f955e83e2ed1?rik=3X2tgl7SFWraKw&riu=http%3a%2f%2f1.bp.blogspot.com%2f-1aDDAFDgC-8%2fUvP8zD5e17I%2fAAAAAAAAHZ4%2fgfedoGd8clc%2fs1600%2fNB15-A1101KL_ANGLE1.jpg&ehk=C657lfH8YNaM6qREyYsxAdhFG%2bgxEgxG0hwL7nMideI%3d&risl=&pid=ImgRaw&r=0");

        Producto producto2 = new Producto("Telcado", 120000.0, "https://cdn.shopify.com/s/files/1/0090/9701/9456/products/max_178457pro_2_1024x1024.jpg?v=1554145757");
        Producto producto3 = new Producto("Mouse",80000.0,"https://4.bp.blogspot.com/-4tQ8qO7iHa8/UpYVisG3XDI/AAAAAAAAPwc/1hhXAc1VU1M/s1600/AVIOR+7000+6+White+BG.jpg");
        Producto producto4 = new Producto("Audifonos", 170000.0,"https://cosonyb2c.vtexassets.com/arquivos/ids/275613-800-800?v=637033513456500000&width=800&height=800&aspect=true");
        Producto producto5 = new Producto("Grafica Nvidia", 630000.0,"https://www.asus.com/media/global/gallery/Nnm00JHVutes6D3z_setting_xxx_0_90_end_800.png");

        //Inicializar el ArrayList

        listaPrincipalProductos = new ArrayList<>();

        //Agregar los productos al arraylist

        listaPrincipalProductos.add(producto1);
        listaPrincipalProductos.add(producto2);
        listaPrincipalProductos.add(producto3);
        listaPrincipalProductos.add(producto4);
        listaPrincipalProductos.add(producto5);

    }

    public void agregarProducto(View view)
    {
        startActivity(new Intent(this, FormularioActivity.class));
    }

    public void clickCerrarSesion(View view) {
        SharedPreferences misPreferencias = getSharedPreferences("tienda_app", MODE_PRIVATE);
        SharedPreferences.Editor miEditor = misPreferencias.edit();
        miEditor.clear();
        miEditor.apply();

        startActivity(new Intent(this, LoginActivity.class));
    }
}