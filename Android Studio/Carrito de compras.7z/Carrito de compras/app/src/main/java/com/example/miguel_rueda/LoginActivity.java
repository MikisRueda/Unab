package com.example.miguel_rueda;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.*;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    private EditText etUsuario, etContraseña;
    private SharedPreferences misPreferencias;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        referenciar();

        misPreferencias = getSharedPreferences("tienda_app", MODE_PRIVATE);

        //VERIFICACION

        if(misPreferencias.getBoolean("logeado", false) == true)
        {
            Intent miIntent = new Intent(this, MainActivity.class);
            startActivity(miIntent);
            finish();
        }
    }

    private void referenciar(){
        etUsuario = findViewById(R.id.et_usuario);
        etContraseña = findViewById(R.id.et_contraseña);
    }

    public void iniciarSesion(View view){
        String usuario = "mrueda261";
        String contraseña = "1234";

        String user = etUsuario.getText().toString();
        String pass = etContraseña.getText().toString();

        if (usuario.equals(user) && contraseña.equals(pass)){

            SharedPreferences.Editor myEditor = misPreferencias.edit();
            myEditor.putBoolean("logeado", true);
            myEditor.apply();

            Intent miIntent = new Intent(this, MainActivity.class);
            startActivity(miIntent);
            finish();
            Toast.makeText(this, "Sesión iniciada", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this, "Credenciales incorrectas", Toast.LENGTH_SHORT).show();
        }

    }
    
}
